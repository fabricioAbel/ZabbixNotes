<?php
function autent_ldap($user, $passw)
{
        $conexao_ldap = ldap_connect("") or die("could not connect to ldap server");//example: ldaserver.domain.br
        if($conexao_ldap)
                return ldap_bind($conexao_ldap, $user, $passw); //return ldap_bind(ldap_connect, bind_rdn, bind_password);
		
}

?>
