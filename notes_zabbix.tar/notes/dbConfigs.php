<?php
$server = "";//"localhost";
$user   = "";//"zabbix";
$pwd    = "";
$dbName = "";//"zabbix";
?>

