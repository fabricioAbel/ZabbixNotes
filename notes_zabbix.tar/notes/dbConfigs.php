<?php
$server = "localhost";
$user   = "zabbix";
$pwd    = "@18_bd";
$dbName = "officialzabbix";
?>

